from flask import Flask, render_template, jsonify
import requests

app = Flask(__name__)

# SDN Controller Credentials
BASE_URL = "http://localhost:58000/api/v1"
LOGIN_URL = f"{BASE_URL}/ticket"
USERNAME = "admin"
PASSWORD = "Ssjcoe123@#"

def get_service_ticket():
    """Authenticate and retrieve the service ticket."""
    response = requests.post(LOGIN_URL, json={"username": USERNAME, "password": PASSWORD})
    if response.status_code == 201:
        return response.json().get("response", {}).get("serviceTicket")
    return None

@app.route('/')
def home():
    """Home Page"""
    return render_template('home.html')

@app.route('/devices')
def devices():
    """Fetch and display network devices."""
    ticket = get_service_ticket()
    if not ticket:
        return "Authentication failed!", 401

    headers = {"X-Auth-Token": ticket}
    response = requests.get(f"{BASE_URL}/network-device", headers=headers)

    if response.status_code == 200:
        devices = response.json().get("response", [])
        return render_template('devices.html', devices=devices)
    return "Failed to fetch devices", 500

@app.route('/health')
def health():
    """Fetch and display network health."""
    ticket = get_service_ticket()
    if not ticket:
        return "Authentication failed!", 401

    headers = {"X-Auth-Token": ticket}
    response = requests.get(f"{BASE_URL}/assurance/health", headers=headers)

    if response.status_code == 200:
        health_data = response.json()
        return render_template('health.html', health=health_data)
    return "Failed to fetch network health", 500

if __name__ == '__main__':
    app.run(debug=True)
